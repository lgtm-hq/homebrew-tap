import click

@click.command()
@click.version_option("0.0.1", prog_name="winnow")
def main() -> None:
    click.echo("winnow")
