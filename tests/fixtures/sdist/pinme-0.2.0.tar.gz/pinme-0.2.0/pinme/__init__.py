"""Fixture package for homebrew-tap resource pinning tests."""
