"""Fixture CLI."""


def main() -> None:
    """Print a version."""
    print("pinme 0.2.0")
